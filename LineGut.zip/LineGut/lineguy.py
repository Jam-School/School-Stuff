# Jordan AM
# 7
# File I/0 Practice
# Time Spent: 30 minutes



mem = open("Mem.txt", 'w') #write to mem

mem.write("Log:" + '\n')#writing stuff
mem.write("You used:" + '\n')
mem.write("2432 gigs of mem:" + '\n')
mem.write("look at this nerd checking his log")

mem.close()
            #close and reopen in read
mem = open("Mem.txt", 'r')

print(mem.readline())
print(mem.readline())#read mem
print(mem.readline())
print("This may not be the full log, please check the mem file for more info.")
input("Press Enter to exit...")#Needing an exit thing
