If you open with VS then you gotta tell it to open with python a few times before actually opening it by double clicking and then it will open right, I don't know why it does this but it does. Note that text commands do nothing at the moment.

commands:
timer: makes a timer
close: closes a window
move: moves a window
open: opens a window
website: opens a website
remember to use commit and not enter to send text commands

talk button: random talk