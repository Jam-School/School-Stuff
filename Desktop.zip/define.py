from tkinter import *

#HARD CODED DO NOT TOUCH!
window = Tk() #Creating window



#SOFT CODED CAN BE CHANGED. DO NOT CHANGE THE VAR NAME AT THE START OF THE LINE.
image1 = PhotoImage(file='images/image1.png')#All the images the assistant uses


talklist = ["test 1", "test 2", "test 3", "holy molly!"]
urllist = ["https://www.google.com/", "https://www.youtube.com", "https://www.renpy.org", "https://www.java.com/en/", "https://www.python.org/", "https://youtu.be/Ax2HvZUPPS8?si=XdMNxSpqdlbb6mX3"]
