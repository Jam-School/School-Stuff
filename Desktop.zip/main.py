import os
import time
import random
import webbrowser
from tkinter import *
from define import * 

talkwinopen = False

def randomtalk(talk): #Random talk from passed in list, usually "talklist" from the define file
    _ = os.system('cls')
    mes = random.choice(talk)
    print(mes)
    return(mes)

def talkwindow(text): #Not used but might be later
    global talkwinopen
    talkwinopen = True  
    talk_window = Toplevel(window)
    talk_window.overrideredirect(False)
    Label(talk_window, text=text).pack()
    time.sleep(random.randint(10, 15))
    talkwinopen = False
    talk_window.destroy()

def urlload(urls):
    url = random.choice(urls)
    return(url)


window.title("Desktop buddy")
label = Label(image=image1, bg='gray').pack() #window settings to make the image and background transparent
window.overrideredirect(False)
window.wm_attributes('-transparentcolor','gray')

opt_window = Toplevel(window) #Options/input window 
opt_window.geometry("300x150")
opt_window.overrideredirect(False)
Label(opt_window, text="this is the options and command window!").pack()
opt_button = Button(opt_window, text="talk", command=lambda: randomtalk(talklist), width=13, height=2).pack()

def retrieve_input(): #Checks user input for command
    inputValue=str(comBox.get("1.0","end-1c")).lower()
    print(inputValue)
    if "timer" in inputValue: #The command check
        _ = os.system('cls')
        print("Making timer!")
    elif "close" in inputValue:
        _ = os.system('cls')
        print("Closing window!")
    elif "move" in inputValue:
        _ = os.system('cls')
        print("Moving window!")
    elif "open" in inputValue:
        _ = os.system('cls')
        print("Opening window!")
    elif "website" in inputValue:
        _ = os.system('cls')
        print("Opening website!")
        webbrowser.open_new(urlload(urllist))
    else:
        print("Please enter a command!")

comBox=Text(opt_window, height=2, width=10) #command input box on the input window
comBox.pack()
Commitbutton=Button(opt_window, height=1, width=10, text="Commit", command=lambda: retrieve_input())
Commitbutton.pack()

while True: #MAIN LOOP, THINGS AFTER WILL NEVER RUN!
    window.update_idletasks()
    window.update()

